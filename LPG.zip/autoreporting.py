# -*- coding: utf-8 -*-
"""
Created on Sat Mar 21 19:47:56 2020

@author: Barreneche_A

"""

import pandas as pd

#Jinja2 creates HTML pages
from jinja2 import FileSystemLoader, Environment

#transforms text URLs into clickable links
from jinja2.utils import urlize

from datetime import datetime

from zipfile import ZipFile
import os

# Allow for very wide columns - otherwise columns are spaced and ellipse'd
pd.set_option("display.max_colwidth", 200)

# Configure Jinja2 and ready the loader
env = Environment(
    loader=FileSystemLoader(searchpath="templates")
)

# Set URL where data will be published (GitHub account and repository)
URL = "https://GITHUBACCOUNT.github.io/REPOSITORYNAME/"

# Assemble the templates we'll use with Jinja2
question_template = env.get_template("reportQ.html")
country_template = env.get_template("reportC.html")
table_section_template = env.get_template("table_section.html")

menu_template = env.get_template("report2.html")

#Function to transform the pandas dataframe into a HTML
def csv_to_Dhtml(filepath):
    """
    Open a .csv file and return it in HTML format.
    :param filepath: Filepath to a .csv file to be read.
    :return: String of HTML to be published.
    """
    pd.set_option('display.max_colwidth', -1)
    df = pd.read_csv(filepath, index_col=0, encoding="utf-8")
    
    #Make URLs into clickable links
    df['Response'] = df['Response'].apply(lambda x: urlize(x, 40, target='_blank'))
    
    irows = list(df.index.values) 
    #In country tables, store submit date (date the survey was answered)
    if 'submitdate' in irows:
        col = list(df.columns)
        rdate = df.at['submitdate', col[0]]
        df.drop('submitdate', inplace=True)
    #In question tables, there is no single submitdate
    else:
        rdate=0
    
    #Transform dataframe to HTML. Several of the options here are linked to the CSS in the html templates defined above.
    html = df.to_html(index_names=False, classes=['table-striped', 'table-bordered'], escape=False, table_id="Qtable").replace("\\n","<br>").replace("\\r","")
    
    #Return list with two objects, submit date and html table
    Dhtml = [rdate,html]
    return Dhtml

#This main() receives a list object with two lists.
def main(anstable):

    #You need a csv file that contains a table with the question codes and the corresponding labels
    #A file is included as an example.
    #This could probably be automated using the API function "list_questions" in limesurvey.py.
    questions_df = pd.read_csv('survey_questions.csv', index_col=0)
    
    #Produce reports by question
    qlinks = []
    for col in anstable[0]:
        qlinks.append("<a href=" + URL + str(col) + ".html\">" + str(questions_df.loc[col,'text']) + "</a>")
        title = str(questions_df.at[col, 'text'])
        csvdata = csv_to_Dhtml("data/data_question/" + str(col) + ".csv")
        responsedate = csvdata[0]
        section = table_section_template.render(table=csvdata[1])
    
        with open("data/outputs/"+ str(col) + ".html", "w", encoding="utf-8") as f:
            output = question_template.render(title=title, submitdate=responsedate, section=section, table_id="Qtable") 
            f.write(output)
    
    #Produce reports by country
    clinks = []
    for col in anstable[1]:
        clinks.append("<a href=\"https://stiplab.github.io/Covid19/" +str(col) + ".html\">" + str(col) + "</a>")
        title = str(col)
        csvdata = csv_to_Dhtml("data/data_country/" + str(col) + ".csv")
        responsedate = csvdata[0]
        section = table_section_template.render(table=csvdata[1])
    
        with open("data/outputs/"+ str(col) + ".html", "w", encoding="utf-8") as f:
            output = country_template.render(title=title, submitdate=responsedate, section=section, table_id="Qtable") 
            f.write(output)
    
    #Generate a menu table with links to the data and save it to datalinks.html
    qlinks_df = pd.DataFrame(qlinks, columns = ['Survey responses by question'])
    qlinks_df.reset_index(inplace=True)
    clinks_df = pd.DataFrame(clinks, columns = ['Survey responses by country'])
    clinks_df.reset_index(inplace=True)
    
    anstable_df = pd.concat([clinks_df, qlinks_df], axis = 1, sort=False)
    anstable_df[" "] = " "
    anstable_df = anstable_df[['Survey responses by country', " ", 'Survey responses by question']]
    anstable_df.fillna('', inplace=True)
    
    #Transform menu dataframe to HTML. Several of the options here are linked to the CSS in the html templates defined above.
    anstable_html = anstable_df.to_html(index_names=False, index=False, classes=['table','custom'], escape=False, table_id="Qtable").replace('border="1"','border="0"')
    section = table_section_template.render(table=anstable_html)
    
    now = datetime.now()
    dt_string = now.strftime("%d/%m/%Y %H:%M:%S")
    
    with open("data/outputs/datalinks.html", "w", encoding="utf-8") as f:
            output = menu_template.render(submitdate=dt_string, section=section, table_id="Qtable") 
            f.write(output)

    # create a ZIP backup of the the data and html files    
    dt_stamp = now.strftime("%d%m%Y-%H%M%S")    
    zipName = str(dt_stamp) + ".zip"
    dirName = "data"
        
    with ZipFile(zipName, 'w') as zipObj:
       # Iterate over all the files in directory
       for folderName, subfolders, filenames in os.walk(dirName):
           for filename in filenames:
               #create complete filepath of file in directory
               filePath = os.path.join(folderName, filename)
               # Add file to zip
               zipObj.write(filePath) 


if __name__ == "__main__":
    main()
