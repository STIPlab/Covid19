# -*- coding: utf-8 -*-
"""
Created on Wed Mar 18 13:16:16 2020

@author: Barreneche_A
"""

LIME_USER = 'INSERT YOUR USERNAME'
LIME_KEY = 'INSERT YOUR PASSWORD'
LIME_API_URL = 'https://survey.oecd.org/index.php?r=admin/remotecontrol'
LIME_TOKEN_BASE = 'token'
LIME_SID = 'INSERT YOUR SURVEY ID'