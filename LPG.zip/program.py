# -*- coding: utf-8 -*-
"""
Created on Fri Mar 20 11:54:05 2020

@author: Barreneche_A

"""
#Pull the data from Limesurvey
import survey_import

#Generate HTML files from data
import autoreporting

#Upload files to GITHUB
import upload


answers = survey_import.main()

autoreporting.main(answers)

upload.main(answers)