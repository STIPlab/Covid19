# -*- coding: utf-8 -*-
"""
Created on Wed Mar 18 20:02:54 2020

@author: Barreneche_A

REQUIRES the following installation using the Anaconda powershell
conda install -c conda-forge pygithub

"""

import base64
from github import Github
from github import InputGitTreeElement

user = "GITHUB_ACCOUNT"
password = "GITHUB_PASSWORD"
g = Github(user,password,verify=False)
repo = g.get_user().get_repo('GITHUB_REPOSITORY')

def main(anstable):
    
    file_list = []
    for ans in anstable[0]:
        file_list.append("data/outputs/" + str(ans) + ".html")
    for ans in anstable[1]:
        file_list.append("data/outputs/" + str(ans) + ".html")
    file_list.append("data/outputs/datalinks.html")
    file_list.append("responses.csv")
    
    file_names = []
    for ans in anstable[0]:
        file_names.append(str(ans) + ".html")
    for ans in anstable[1]:
        file_names.append(str(ans) + ".html")
    file_names.append("datalinks.html")
    file_names.append("responses.csv")
    
    commit_message = 'python update'
    master_ref = repo.get_git_ref('heads/master')
    master_sha = master_ref.object.sha
    base_tree = repo.get_git_tree(master_sha)
    element_list = list()
    for i, entry in enumerate(file_list):
        with open(entry, encoding="utf-8") as input_file:
            data = input_file.read()
        if entry.endswith('.png'):
            data = base64.b64encode(data)
        element = InputGitTreeElement(file_names[i], '100644', 'blob', data)
        element_list.append(element)
    tree = repo.create_git_tree(element_list, base_tree)
    parent = repo.get_git_commit(master_sha)
    commit = repo.create_git_commit(commit_message, tree, [parent])
    master_ref.edit(commit.sha)

if __name__ == "__main__":
    main()
