# -*- coding: utf-8 -*-
"""
Created on Wed Mar 18 10:30:03 2020

@author: Barreneche_A

REQUIRES the following installation using the Anaconda powershell
conda install -c anaconda git

"""
#Load the functions to query the Limesurvey API
from limesurvey import Api

#Load configuration file with your Limesurvey username and password (request to Brunella Boselli)
#and the ID of the survey you want to pull the data from
import config

from pandas import DataFrame, Series, read_csv, concat, to_datetime
from numpy import NaN

def main():
    
    # Authentication
    user = config.LIME_USER
    key = config.LIME_KEY
    url = config.LIME_API_URL
    
    # Build the API
    lime = Api(url, user, key)
    
    # SET TOKEN BASE and Survey
    sid = config.LIME_SID
    token = config.LIME_TOKEN_BASE
    
    #extract data
    extraction = lime.export_responses(sid, token)
    
    #transform responses to dataframe
    reformat = DataFrame(extraction)
    reformat2 = reformat.drop('responses',1).join(reformat.responses.apply(Series))
    reformat3 = reformat2.T.stack().values
    reformat4 = DataFrame(reformat3, columns=['a'])
    responses_df = reformat4.a.apply(Series)
    
    #Replace tabs with spaces
    responses_df.replace(to_replace=[r"\\t", "\t"], value=" ", regex=True, inplace=True)
    
    #Set country as dataframe index and sort. 
    #IMPORTANT: This means you need a question with the COUNTRY code in your survey.
    #This question can be a hidden question that automatically takes the value of a hidden field in your participants table.
    #Brunella Boselli (SDD/SDPS) can advise on how to set this up in Limesurvey.
    responses_df.set_index('COUNTRY', inplace=True)
    responses_df.sort_index(inplace=True)
    
    #Remove unnecessary data
    responses_df.drop(columns=['id', 'lastpage', 'startlanguage', 'token', 'seed', 'startdate', 'datestamp'], inplace=True)
    
    #Replace blank responses, with N/A, '-', just blank spaces, with NaN
    responses_df.replace("N/A", NaN, inplace=True)
    responses_df.replace("nan", NaN, inplace=True)
    responses_df.replace("-", NaN, inplace=True)
    responses_df.replace(r'^\s*$', NaN, regex=True, inplace=True)
    
    #Drop empty responses from dataframe. 'submitdate' is considered a response, so we set the threshold at 2.
    responses_df.dropna(axis=0, thresh=2, how='all', inplace=True)
    
    #save answers to file
    responses_df.to_csv("responses.csv")
    
    #Reformat submitdate in dataframe
    responses_df['submitdate'] = to_datetime(responses_df['submitdate']).dt.date
    
    #save answers by question
    qcodes = list(responses_df.columns)
    qcodes.remove('submitdate')
    for col in qcodes:
        tdf = col
        tdf = DataFrame(data=responses_df[['submitdate',col]].values, index=responses_df.index, columns=['Updated on', 'Response'])
        edf = tdf.dropna()
        edf.to_csv("data/data_question/" + str(col) + ".csv")
    
    #You need a csv file that contains a table with the question codes and the corresponding labels
    #A file is included as an example.
    #This could probably be automated using the API function "list_questions" in limesurvey.py.
    questions_df = read_csv('survey_questions.csv', index_col=0)
    
    #Transpose data frame
    responsesC_df = responses_df.T
    responsesC_df = concat([questions_df, responsesC_df], axis=1, sort=True)
    responsesC_df.set_index('text', inplace=True)
    responsesC_df.fillna('[Left blank]', inplace=True)
    
    #save answers by country
    countries = list(responsesC_df.columns)
    for col in countries:
        tdf = col
        tdf = DataFrame(data=responsesC_df[[col]].values, index=responsesC_df.index, columns=['Response'])
        tdf.to_csv("data/data_country/" + str(col) + ".csv")
    
    #main() returns the questions and countries that have answered the survey.
    #In the form of a nested list, i.e. a list with two items, each of them being a list.
    answers = [qcodes,countries]
    return answers
    

if __name__ == "__main__":
    main()


